public class N1 
{
    public static void main(String[] args) 
    {
        int vet1[] = new int [10]; 
        int vet2[] = new int [10];    

        int j = 9;
        System.out.printf("%nImprimindo o vetor 1: %n%n");
        for (int i=0; i<vet1.length; i++) {
            vet1[i] = i+1;
            System.out.printf("Posição %d do vetor 1: %d%n", i, vet1[i]);
            vet2[j] = vet1[i];
            j--;
        }
        
        System.out.printf("%nImprimindo o vetor 2: %n%n");
        for (int i=0; i<vet2.length; i++) {
            System.out.printf("Posição %d do vetor 2: %d%n", i, vet2[i]);
        }
    }
}